//
//  ViewController.h
//  TableViewDemo
//
//  Created by TheAppGuruz-New-6 on 06/05/14.
//  Copyright (c) 2014 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property NSArray *colors;

@end
